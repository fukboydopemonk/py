class AuthEmail:
    email = 'koloyar40@gmail.com'
    password = '3942210Zx'

class AuthPhone:
    phone = '9605194622'
    password = '3942210Zx'

class AuthLogin:
    login = 'rtkid_1671718933161'
    password = '3942210Zx'

class InvalidData:
    login = 'login_non_true'
    password = "3942210zX"

class SymbolData:
    login = '/*!@#$'
    password = "3942210zX"

class KirillData:
    login = 'Кириллица'
    password = "Кириллица"

class BIGData:
    login = 'login'
    password = "passw"