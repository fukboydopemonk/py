# Module_25
Task 25_5_1

